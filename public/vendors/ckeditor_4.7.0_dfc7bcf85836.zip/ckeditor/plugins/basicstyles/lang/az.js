﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'az', {
	bold: 'Qalın',
	italic: 'Kursiv',
	strike: 'Üstüxətli',
	subscript: 'Aşağı indeks',
	superscript: 'Yuxarı indeks',
	underline: 'Altdan xətt'
} );
