﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'es', {
	ltr: 'Dirección del texto de izquierda a derecha',
	rtl: 'Dirección del texto de derecha a izquierda'
} );
