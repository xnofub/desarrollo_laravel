﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'hr', {
	copy: 'Autorsko pravo &copy; $1. Sva prava pridržana.',
	dlgTitle: 'O CKEditoru',
	help: 'Provjeri $1 za pomoć.',
	moreInfo: 'Za informacije o licencama posjetite našu web stranicu:',
	title: 'O CKEditoru',
	userGuide: 'Vodič za CKEditor korisnike'
} );
